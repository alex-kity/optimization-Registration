// SPDX-License-Identifier: LGPL-2.0-or-later
// Copyright © EDF R&D / TELECOM ParisTech (ENST-TSI)

#pragma once

//Local
#include "CCTypes.h"

namespace CCCoreLib
{
	//! Empty class - for classification purpose only
	class MathTools {};
}
