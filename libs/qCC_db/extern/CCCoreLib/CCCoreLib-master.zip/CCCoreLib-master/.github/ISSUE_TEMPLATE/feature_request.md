---
name: Feature request
about: Suggest an idea for the CCCoreLib project
title: ''
labels: enhancement
assignees: ''
---

**Describe the feature you would like**
<!--- Add a clear & concise description of the feature you are requesting. -->

**Describe alternatives you've considered**
<!--- Add a clear & concise description of any alternative solutions or features you've considered. -->

**Is your feature request related to a problem? Please describe.**
<!--- Add a clear & concise description of what the problem is. Ex. I'm always frustrated when [...] -->

**Additional context**
<!--- Add any other context or screenshots about the feature request here. -->
