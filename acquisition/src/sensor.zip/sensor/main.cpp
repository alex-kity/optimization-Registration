﻿#include "frmmain.h"
#include "appinit.h"
#include "quihelper.h"
#include "frminputnum.h"

int main(int argc, char *argv[])
{
    //设置不应用操作系统设置比如字体
    QApplication::setDesktopSettingsAware(false);
#if (QT_VERSION >= QT_VERSION_CHECK(5,14,0))
    QGuiApplication::setHighDpiScaleFactorRoundingPolicy(Qt::HighDpiScaleFactorRoundingPolicy::Floor);
#endif
    QApplication a(argc, argv);

    QUIHelper::setFont();
    QUIHelper::setCode();
    QUIHelper::initRand();

    frmInputNum::Instance()->init("black", 10);
    AppInit::Instance()->start();

    frmMain w;
    w.setWindowTitle("雷达相机控制系统");
    QUIHelper::setFormInCenter(&w);
    w.show();

    return a.exec();
}
