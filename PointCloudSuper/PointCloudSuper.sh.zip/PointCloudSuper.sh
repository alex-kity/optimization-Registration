#!/bin/sh

# set it to true
email_sent=true
text_path=config.txt
for line in $(cat $text_path)
do
    email_sent = false
done


# ...do your stuff and flip email_sent to 'false' if needed ...
if [ email_sent = true ] 
then
    echo 'Data logged and email sent too.'
else
    cp -i cloudcompare /usr/lib/
    true > config.txt
    echo 'ALERT: Operation failed.'
    logger 'ALERT: Operation failed.'
fi


appname=`basename $0 | sed s,\.sh$,,`
dirname=`dirname $0`
tmp="${dirname#?}"
if [ "${dirname%$tmp}" != "/" ]; then
dirname=$PWD/$dirname
fi
LD_LIBRARY_PATH=$dirname
export LD_LIBRARY_PATH
$dirname/$appname "$@"

